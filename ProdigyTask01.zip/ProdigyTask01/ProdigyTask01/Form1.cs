namespace ProdigyTask01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtTemperature_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            try
            {
                double temperature = Convert.ToDouble(txtTemperature.Text);
                string unit = cmbUnit.Text;

                double fahrenheit = 0;
                double celsius = 0;
                double kelvin = 0;

                if (unit == "Celsius �C")
                {
                    fahrenheit = (temperature * 9 / 5) + 32;
                    kelvin = temperature + 273.15;
                    celsius = temperature;
                }
                else if (unit == "Fahrenheit �F")
                {
                    celsius = (temperature - 32) * 5 / 9;
                    kelvin = celsius + 273.15;
                    fahrenheit = temperature;
                }
                else if (unit == "Kelvin �K")
                {
                    celsius = temperature - 273.15;
                    fahrenheit = (celsius * 9 / 5) + 32;
                    kelvin = temperature;
                }
                
                celsiusAnsw.Text = celsius.ToString("F2");
                fahrenAnsw.Text = fahrenheit.ToString("F2");
                kelAnsw.Text = kelvin.ToString("F2");
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid numeric temperature.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtTemperature.Clear();
            cmbUnit.SelectedIndex = -1;
            celsiusAnsw.Clear();
            fahrenAnsw.Clear();
            kelAnsw.Clear();
        }
    }
}
