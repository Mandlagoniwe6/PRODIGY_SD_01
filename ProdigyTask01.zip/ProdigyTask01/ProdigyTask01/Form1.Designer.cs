﻿namespace ProdigyTask01
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnConvert = new Button();
            cmbUnit = new ComboBox();
            lblUnit = new Label();
            lblTemperature = new Label();
            txtTemperature = new TextBox();
            btnClear = new Button();
            panel1 = new Panel();
            groupBox1 = new GroupBox();
            celsiusAnsw = new TextBox();
            kelAnsw = new TextBox();
            fahrenAnsw = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            panel1.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 21.75F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(376, 50);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(306, 40);
            label1.TabIndex = 0;
            label1.Text = "Temperature Converter";
            label1.TextAlign = ContentAlignment.TopCenter;
            label1.Click += label1_Click;
            // 
            // btnConvert
            // 
            btnConvert.BackColor = Color.DarkOrange;
            btnConvert.Location = new Point(376, 379);
            btnConvert.Margin = new Padding(6);
            btnConvert.Name = "btnConvert";
            btnConvert.Size = new Size(139, 49);
            btnConvert.TabIndex = 2;
            btnConvert.Text = "Convert";
            btnConvert.UseVisualStyleBackColor = false;
            btnConvert.Click += btnConvert_Click;
            // 
            // cmbUnit
            // 
            cmbUnit.FormattingEnabled = true;
            cmbUnit.Items.AddRange(new object[] { "Celsius °C", "Fahrenheit °F", "Kelvin °K" });
            cmbUnit.Location = new Point(348, 310);
            cmbUnit.Margin = new Padding(6);
            cmbUnit.Name = "cmbUnit";
            cmbUnit.Size = new Size(355, 40);
            cmbUnit.TabIndex = 3;
            // 
            // lblUnit
            // 
            lblUnit.AutoSize = true;
            lblUnit.Location = new Point(376, 272);
            lblUnit.Margin = new Padding(6, 0, 6, 0);
            lblUnit.Name = "lblUnit";
            lblUnit.Size = new Size(301, 32);
            lblUnit.TabIndex = 4;
            lblUnit.Text = "Select unit to convert from";
            // 
            // lblTemperature
            // 
            lblTemperature.AutoSize = true;
            lblTemperature.Location = new Point(417, 169);
            lblTemperature.Margin = new Padding(6, 0, 6, 0);
            lblTemperature.Name = "lblTemperature";
            lblTemperature.Size = new Size(223, 32);
            lblTemperature.TabIndex = 5;
            lblTemperature.Text = "Enter Temperature: ";
            lblTemperature.Click += label3_Click;
            // 
            // txtTemperature
            // 
            txtTemperature.Location = new Point(348, 207);
            txtTemperature.Margin = new Padding(6);
            txtTemperature.Name = "txtTemperature";
            txtTemperature.Size = new Size(355, 39);
            txtTemperature.TabIndex = 6;
            txtTemperature.TextChanged += txtTemperature_TextChanged;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.Chartreuse;
            btnClear.Location = new Point(538, 379);
            btnClear.Margin = new Padding(6);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(139, 49);
            btnClear.TabIndex = 7;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            btnClear.Click += btnClear_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.BlueViolet;
            panel1.Controls.Add(label1);
            panel1.Location = new Point(0, 5);
            panel1.Margin = new Padding(6);
            panel1.Name = "panel1";
            panel1.Size = new Size(1010, 134);
            panel1.TabIndex = 8;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(celsiusAnsw);
            groupBox1.Controls.Add(kelAnsw);
            groupBox1.Controls.Add(fahrenAnsw);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Location = new Point(348, 459);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(355, 193);
            groupBox1.TabIndex = 9;
            groupBox1.TabStop = false;
            groupBox1.Text = "Answers";
            // 
            // celsiusAnsw
            // 
            celsiusAnsw.Location = new Point(160, 32);
            celsiusAnsw.Margin = new Padding(6);
            celsiusAnsw.Name = "celsiusAnsw";
            celsiusAnsw.ReadOnly = true;
            celsiusAnsw.Size = new Size(169, 39);
            celsiusAnsw.TabIndex = 8;
            // 
            // kelAnsw
            // 
            kelAnsw.Location = new Point(160, 134);
            kelAnsw.Margin = new Padding(6);
            kelAnsw.Name = "kelAnsw";
            kelAnsw.ReadOnly = true;
            kelAnsw.Size = new Size(169, 39);
            kelAnsw.TabIndex = 11;
            // 
            // fahrenAnsw
            // 
            fahrenAnsw.Location = new Point(160, 83);
            fahrenAnsw.Margin = new Padding(6);
            fahrenAnsw.Name = "fahrenAnsw";
            fahrenAnsw.ReadOnly = true;
            fahrenAnsw.Size = new Size(169, 39);
            fahrenAnsw.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 137);
            label4.Margin = new Padding(6, 0, 6, 0);
            label4.Name = "label4";
            label4.Size = new Size(91, 32);
            label4.TabIndex = 7;
            label4.Text = "Kelvin: ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(9, 90);
            label3.Margin = new Padding(6, 0, 6, 0);
            label3.Name = "label3";
            label3.Size = new Size(139, 32);
            label3.TabIndex = 6;
            label3.Text = "Fahrenheit: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(9, 35);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(100, 32);
            label2.TabIndex = 5;
            label2.Text = "Celsius: ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDark;
            ClientSize = new Size(1009, 664);
            Controls.Add(groupBox1);
            Controls.Add(panel1);
            Controls.Add(btnClear);
            Controls.Add(txtTemperature);
            Controls.Add(lblTemperature);
            Controls.Add(lblUnit);
            Controls.Add(cmbUnit);
            Controls.Add(btnConvert);
            Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(6);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnConvert;
        private ComboBox cmbUnit;
        private Label lblUnit;
        private Label lblTemperature;
        private TextBox txtTemperature;
        private Button btnClear;
        private Panel panel1;
        private GroupBox groupBox1;
        private TextBox fahrenAnsw;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox celsiusAnsw;
        private TextBox kelAnsw;
    }
}
